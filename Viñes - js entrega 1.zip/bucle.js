for(let i = 0; i <= 100; i++){
    let nombre = prompt("Ingrese su nombre para sacar turno");
    let mensaje = `${nombre} , su lugar en la fila es el #${i}`;
    alert(mensaje)
}

alert("Se acabaron los turnos")