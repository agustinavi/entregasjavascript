
let usuario = prompt("Ingrese el usuario");

while(usuario.toLowerCase != "Agustina"){
    alert("Usuario incorrecto")
    usuario = prompt("Ingrese el usuario")
}

alert("Bienvenida Agustina!")

